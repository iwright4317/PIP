<html>
<head>
<title>Thoroughgood News</title>
</head>
<BODY >
<center> 
 <form name="form1" method="post" action="StoreProfile.php">
 	<input type="hidden" name="id" value=<?php echo $_GET['id']; ?>>
    <table border="0" bgcolor="000000" cellpading=0 cellspacing="1" width="95%">
      <tr bgcolor="#FFFFE8"> 
        <td colspan="3"> 
          <b><font face="Arial, Helvetica, sans-serif" size="5">Thoroughgood News - User
 Profile&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=http://thewrightrealtor4u.com/wordpress/>Home</a><br>
          <font size="3">Please use this form to record your preferrences to receiving 
          news alerts depending on category. After you store your user profile, 
          you will start to recieve notices from your selected categories.</font></font></b></td>
      </tr>
      <tr bgcolor="#FFFFE8"> 
        <td width="25%"> 
          <div align="right">Enter your email address:
	  <input type="text" name="Email" size="30"></div>
        </td>
        <td width="75%" colspan="2"> 
          <!-- <div align="left">Enter the T-News name: 
	  <input type="text" name="firstname" size="30"> -->
	  		&nbsp;
        </td>
      </tr>
      <tr bgcolor="#FFFFE8"> 
        <td colspan="3">Please select all news categories from which you would 
          like to receive notification of new information</td>
      </tr>
      
      <tr bgcolor="#FFFFE8"> 
        <td > 
          <input type="checkbox" name="checkbox1" value="y" checked>
          Civic league events<br>(picnics, meetings)</td>
        <td > 
          <input type="checkbox" name="checkbox2" value="y" checked>
          Member news<br>(announcements)</td>
        <td> 
          <input type="checkbox" name="checkbox3" value="y" checked>
          Give-away<br>(valuables to a good home) </td>
      </tr>
      <tr bgcolor="#FFFFE8"> 
        <td width="33%"> 
          <input type="checkbox" name="checkbox4" value="y" checked>
          Crime reports<br>(reported & suspicious activities)</td>
        <td width="33%"> 
          <input type="checkbox" name="checkbox5" value="y" checked>
          Garage Sales<br>(organize, offer)</td>
        <td width="33%"> 
          <input type="checkbox" name="checkbox6" value="y" checked>
          Entertainment Events<br>(movies, sports, concerts)</td>
      </tr>
      <tr bgcolor="#FFFFE8"> 
        <td> 
          <input type="checkbox" name="checkbox7" value="y" checked>
          Professional services<br>(offer, request, evaluate) </td>
        <td> 
          <input type="checkbox" name="checkbox8" value="y" checked>
          Non-professional service<br>(Baby sitting, lawn work <br>offer, request, evaluate) </td>        
        <td> 
          <input type="checkbox" name="checkbox9" value="y" checked>
          Hobbies<br>(scrap-booking, gardening, etc.) </td>
      </tr>
      <tr bgcolor="#FFFFE8">         
        <td> 
          <input type="checkbox" name="checkbox10" value="y" checked>
          Kids <br>(activities, events)</td>
        <td> 
          <input type="checkbox" name="checkbox11" value="y" checked>
          Pets <br>(lost, found, offer, interest)</td>
        <td> 
          <input type="checkbox" name="checkbox12" value="y" checked>
          For sale<br>(items for sale)</td>
      </tr>
      <tr bgcolor="#FFFFE8">
        <td colspan="2">
          <input type="submit" name="Submit" value="Store Your User Profile">
	  <input type="checkbox" name="delete" value="y" >
          Delete this account
        </td>
	<td> 
          <input type="checkbox" name="checkbox14" value="y" checked>
          School News</td>
        <td> 
      </tr>        
    </table>
  </form>
</center>
</body>
</html>
