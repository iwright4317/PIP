
		<a name="login"></a>
		<?php
		if ($_GET['email']  <> "") {
		$connection = mysql_connect("localhost", "vmarch5_ecomm", "bobcatalina66") or die('I cannot connect to the database because: ' . mysql_error());
	$dbc = mysql_select_db("vmarch5_ecommercerw") or die("<p>DB select failed ||<p>" . mysql_error());

		$q = "Select FirstName, Id from VMAR_users Where Email = '" . $_GET['email'] . "' and PassText = '" . $_GET['text2'] . "' ";
		$r = mysql_query($q) or die("<br/>Query failed");

		if ($row = mysql_fetch_array($r)) {
			$_SESSION["user_name"] = $row[0];
			$_SESSION["user_id"] = $row[1];
		} else {
			$_SESSION["user_name"] = "username and password not found";
			$_SESSION["user_id"] = "";
		}}
		?>
		
	<nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="#">VMAR</a>
			</div>
			<div id="navbar" class="collapse navbar-collapse">
				<ul class="nav navbar-nav">
					<li class="active">
						<a href="#">Home...</a>
					</li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Events <span class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
							<li>
								<a href="#">The Vineyard Movement</a>
							</li>
							<li>
								<a href="#">Multiply Vineyard</a>
							</li>
							<li class="divider"></li>
							<li class="dropdown-header">
								Regional Conference
							</li>
							<li>
								<a href="#">Schedule of events</a>
							</li>
							<li>
								<a href="#">Speakers</a>
							</li>
							<li>
								<a href="#">Lodging</a>
							</li>
						</ul>
					</li>

					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Churches <span class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
							<li>
								<a href="#">Leadership</a>
							</li>
							<li>
								<a href="#">Church Directory</a>
							</li>
							<li>
								<a href="#">Church Planting</a>
							</li>
							<li>
								<a href="#">Vineyard USA</a>
							</li>
						</ul>
					</li>

					<li>
						<a href="#contact">Contact</a>
					</li>
						<?php
						If (!isset($_SESSION["user_name"])) {
						?>
					<li>
						<!-- 	<form class="navbar-form navbar-right" action="./includes/login_form.inc.php"> -->
						<form class="navbar-form navbar-right" action="#login">
							<div class="form-group">
								<input type="text" placeholder="Email" class="form-control" name="email">
							</div>
							<div class="form-group">
								<input type="password" placeholder="Password" class="form-control" name="text2">
							</div>
							<button type="submit" class="btn btn-success" >
								Sign in.
							</button>
						</form>
					</li>
					<?php
						}
						?>
				</ul>
				<ul class="nav navbar-nav  navbar-right">
					<?php
						If (isset($_SESSION["user_name"])) {
						?>
					<li >			
						<form class="navbar-form navbar-right" action="asearch.php">
							<button type="submit" class="btn btn-success" >
								Search
							</button>
						</form>	
						</li>
						<li>		
						<form class="navbar-form navbar-right" action="AddContent.php">
							<button type="submit" class="btn btn-success" >
								Add Content
							</button>
						</form>
					</li>
					<li class="navbar-text">
						<?php
						echo "&nbsp;Hello " . $_SESSION["user_name"] . " ";
						?>
					</li>
					<?php
					}
					?>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</nav>